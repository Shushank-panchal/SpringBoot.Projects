package com.junit;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BasicSalaryCalculatorTest {

	private BasicSalaryCalculator basicSalaryCalculator;
	
	@BeforeEach
	void inti() {
		basicSalaryCalculator = new BasicSalaryCalculator();
	}
	@Test
	void testBasicSalaryWithvalidSalary() //positive testcase
	{
		double basicSalary=4000;
		basicSalaryCalculator.setBasicSalary(basicSalary);
		
		//to test SocialInsuarnce
		double expectedSocialInsurance = basicSalary * 0.25; //100 
	    assertEquals(expectedSocialInsurance,basicSalaryCalculator.getSocialInsurance());
	    
	    //to test AditionalBonus
	    double expectedAditionalBonus = basicSalary * 0.1; //100
       assertEquals(expectedAditionalBonus,basicSalaryCalculator.getAdditionalBonus());
        
       double expectedGross = basicSalary+ expectedSocialInsurance+expectedAditionalBonus;
       assertEquals(expectedGross,basicSalaryCalculator.getgrossSalary());
	}
       
       @DisplayName("Test Invalid Salary ")
       @Test
       
    	   void testBasicSalaryWithInvalidSalary()
    	   //Negative TestCase
    	   {
    		   double basicSalary= -100;
    		   assertThrows(IllegalArgumentException.class,() ->{
    			   basicSalaryCalculator.setBasicSalary(basicSalary);
    		   });
    	   
       
	}
}
