package com.entity;

import jakarta.persistence.*;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
   
    @Entity
	@Table(name="student")
	public class Student
	{

			@Id
		    @GeneratedValue(strategy=GenerationType.IDENTITY)
			
		    @Column(name="id")
		    private int id;
			
			@Column(name="name")
		    private String name;
			
			@ManyToOne(cascade=CascadeType.ALL)
		    @JoinColumn(name="teacher_id")
		    private Teacher teacher;

			//Default Constructor
			public Student() {
				super();
			}

			//Parameterized Constructor
			public Student(String name) {
				super();
				this.name = name;
			}

			//getter & Setter
			public int getId() {
				return id;
			}

			public void setId(int id) {
				this.id = id;
			}

			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}
			
				public void setTeacher(Teacher teacher) {
					this.teacher=teacher;
				}
			
			//tosring method
			@Override
			public String toString() {
				return "Student [id=" + id + ", name=" + name + "]";
			}

			
			
		}
			
