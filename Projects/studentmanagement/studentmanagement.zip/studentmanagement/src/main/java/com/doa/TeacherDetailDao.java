package com.doa;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entity.TeacherDetail;
import com.util.HibernateUtil;


	public class TeacherDetailDao {
	    @SuppressWarnings("deprecation")
		public void saveTeacherDetail(TeacherDetail teacherDetail) {
	        Transaction transaction = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            // start a transaction
	            transaction = session.beginTransaction();
	            // save the student object
	            session.save(teacherDetail);
	            // commit transaction
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	    }

	 

	    @SuppressWarnings("deprecation")
		public void updateTeacherDetail(TeacherDetail teacherDetail) {
	        Transaction transaction = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            // start a transaction
	            transaction = session.beginTransaction();
	            Object teacherDetail1 = null;
				// save the student object
	            session.update(teacherDetail1);
	            // commit transaction
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	    }

	 

	    public TeacherDetail getTeacherDetail(int id) {

	       Transaction transaction = null;
	        TeacherDetail teacher = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            // start a transaction
	            transaction = session.beginTransaction();
	            // get an instructor object
	            teacher = session.get(TeacherDetail.class, id);
	            // commit transaction
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	        return teacher;
	    }
	}


