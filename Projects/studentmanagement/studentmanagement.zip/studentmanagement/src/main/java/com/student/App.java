package com.student;
import java.util.*;

import com.doa.StudentDao;
import com.entity.Student;
import com.entity.Teacher;
import com.entity.TeacherDetail;
public class App {
	 public static void main( String[] args )
	    {
	        // Save two instructors
	        Teacher teacher = new Teacher("Amit", "Varma", "amitv45@gmail.com");
	        TeacherDetail teacherDetail = new TeacherDetail("http://www.youtube.com", "Piano");
	        teacherDetail.setTeacher(teacher);
	        teacher.setTeacherDetail(teacherDetail);
	       
	        Teacher teacher1 = new Teacher("Shree", "Kumar", "shreekumar@gmail.com");
	        TeacherDetail teacherDetail1 = new TeacherDetail("http://www.youtube.com", "Guitar");
	        teacherDetail1.setTeacher(teacher1);
	        teacher1.setTeacherDetail(teacherDetail1);
	        
	        List<Student> students=new ArrayList<>();
	        //create some courses
	        Student co=new Student("Akash");
	        co.setTeacher(teacher);
	        students.add(co);
	        StudentDao cod =new StudentDao();
	        cod.saveStudent(co);
	        

	    }


}
