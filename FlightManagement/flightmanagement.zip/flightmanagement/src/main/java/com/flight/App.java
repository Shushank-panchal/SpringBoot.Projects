package com.flight;
//Java Program to Illustrate App File
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.flight.App;
	//Main class
	public class App {

	 // Main driver method
	 public static void main(String[] args)
	 {

	     // Create Configuration
	     Configuration configuration = new Configuration();
	     configuration.configure("hibernate.cfg.xml");
	     configuration.addAnnotatedClass(FlightData.class);

	     // Create Session Factory
	     SessionFactory sessionFactory = configuration.buildSessionFactory();

	     // Initialize Session Object
	     Session session = sessionFactory.openSession();

	     FlightData flight1 = new FlightData();
	     FlightData flight2 = new FlightData();
	     FlightData flight3 = new FlightData();

	     flight1.setId(101);
	     flight1.setFlightName("Indigo Airlines");
	     flight1.setCarrier("American Airlines ");
	     flight1.setCapacity(40);
	     
	     flight2.setId(102);
	     flight2.setFlightName("SpiceJet");
	     flight2.setCarrier("United Airlines, Inc. ");
	     flight2.setCapacity(46);
	     
	     flight3.setId(103);
	     flight3.setFlightName("Air India");
	     flight3.setCarrier("Indian Airlines");
	     flight3.setCapacity(46);


	     session.beginTransaction();

	     // Here we have used
	     // save() method of JPA
	     session.save(flight1);
	     session.save(flight2);
	     session.save(flight3);
	     
	     session.getTransaction().commit();
	 }
	}


