package com.flight;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "flight")
 
//POJO class
public class FlightData {
 
    @Id 
    @Column(name = "flightId")
    private int id;
 
    @Column(name = "flightName")
    private String flightName;
 
    @Column(name = "carrierName") 
    private String carrier;
    
    @Column(name = "totalCapacity")
    private int capacity;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFlightName() {
		return flightName;
	}  

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
    
    }
